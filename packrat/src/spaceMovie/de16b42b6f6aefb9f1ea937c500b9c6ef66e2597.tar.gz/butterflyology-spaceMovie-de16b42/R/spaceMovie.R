#' @title spaceMovie
#' @name spaceMovie
#' @docType package
#' @details list of palettes from the Space Movie franchise
#' @description list of palettes from the Space Movie franchise
NULL
